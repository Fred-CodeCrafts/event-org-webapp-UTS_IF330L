
<?php if (isset($_SESSION['auth']))  ?>

</body>

    <footer id="myFooter">
        <div class="container">
            <div class="row">
            </div>
        </div>

<script src="../assets/vendor/js/jquery-3.4.1.min.js"></script>
<script src="../assets/vendor/js/popper.min.js"></script>
<script src="../assets/vendor/bootstrap-4.3.1/js/bootstrap.min.js"></script>


</body>

</html>
