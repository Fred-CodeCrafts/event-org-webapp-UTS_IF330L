<?php

require 'env.php';

$conn = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE, DB_PORT); // Added DB_PORT

if (!$conn) {
    die("Connection failed: ". mysqli_connect_error());
} 

echo "Connected successfully";
?>
