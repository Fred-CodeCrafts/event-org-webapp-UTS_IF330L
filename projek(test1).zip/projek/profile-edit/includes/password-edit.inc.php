<?php

if (isset($_POST['update-profile'])) {
    
    // Initialize the variable
    $passwordUpdated = false;

    // Retrieve old password, new password, and repeat password
    $oldPassword = trim($_POST['oldPassword']);
    $newpassword = trim($_POST['newpassword']);
    $passwordrepeat = trim($_POST['passwordrepeat']);

    // Check if all password fields are filled
    if (!empty($oldPassword) && !empty($newpassword) && !empty($passwordrepeat)) {
        // Prepare SQL statement to select password
        $sql = "SELECT password FROM user WHERE user_id=?;"; // Ensure the table name is correct
        $stmt = mysqli_stmt_init($conn);

        if (!mysqli_stmt_prepare($stmt, $sql)) {
            $_SESSION['ERRORS']['sqlerror'] = 'SQL ERROR';
            header("Location: ../");
            exit();
        } else {
            mysqli_stmt_bind_param($stmt, "i", $_SESSION['id']);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($row = mysqli_fetch_assoc($result)) {
                // Verify the old password
                $pwdCheck = password_verify($oldPassword, $row['password']);
                
                if ($pwdCheck == false) {
                    $_SESSION['ERRORS']['passworderror'] = 'Incorrect current password';
                    header("Location: ../");
                    exit();
                }
                if ($oldPassword == $newpassword) {
                    $_SESSION['ERRORS']['passworderror'] = 'New password cannot be the same as the old password';
                    header("Location: ../");
                    exit();
                }
                if ($newpassword !== $passwordrepeat) {
                    $_SESSION['ERRORS']['passworderror'] = 'Confirmed password does not match new password';
                    header("Location: ../");
                    exit();
                }

                // If all checks pass, update the password
                $newhashedPassword = password_hash($newpassword, PASSWORD_DEFAULT);

                // Prepare the update statement
                $updateSql = "UPDATE user SET password=? WHERE user_id=?;";
                if (!mysqli_stmt_prepare($stmt, $updateSql)) {
                    $_SESSION['ERRORS']['sqlerror'] = 'SQL ERROR';
                    header("Location: ../");
                    exit();
                } else {
                    mysqli_stmt_bind_param($stmt, "si", $newhashedPassword, $_SESSION['id']);
                    mysqli_stmt_execute($stmt);
                    $passwordUpdated = true; // Set to true after successful update
                }

                if ($passwordUpdated) {
                    $_SESSION['STATUS']['passwordupdated'] = 'Password updated successfully';
                }

            } else {
                $_SESSION['ERRORS']['usererror'] = 'User not found';
                header("Location: ../");
                exit();
            }
        }
    } else {
        $_SESSION['ERRORS']['passworderror'] = 'All password fields are required.';
        header("Location: ../");
        exit();
    }
} else {
    header("Location: ../");
    exit();
}
